import { combineReducers } from "redux";
import updateProps from "./updateProps";

const rootReducer = combineReducers({updateProps});

export default rootReducer;